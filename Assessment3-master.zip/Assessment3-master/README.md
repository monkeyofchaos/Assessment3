# Assessment3
assessment3 ios
Group 177

App ideas
language app, learning languages





mtg Token boardstate app ***

----------------------------

button to start for a "new game" (this would clear the current board state)

create a new token, 

when u create a token you need to be able to sadd name, add power and thoughness, add abilities (this can be done from a checklist) and specify amount of that token

potentially add a save token function that can be accessed from a library of saved tokens for easy access

----------------------------







shopping list app ***

--------------------------------



music composiion app ***

default 5-6 staves
with addition and reduction of staves




-------------------------------
resturant finder by rating

Health App




