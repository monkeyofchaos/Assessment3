//
//  ViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 21/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UIViewController, UIPickerViewDataSource ,UIPickerViewDelegate {
  
    let getURL = "https://api.exchangeratesapi.io/latest?base="
    let currencyCountryRate = ["BGN","NZD","ILS","RUB","CAD","USD","PHP","CHF", "AUD","JPY","TRY","HKD","MYR","HRK","CZK","IDR","DKK","NOK","HUF","GBP","MXN","THB","ISK","ZAR","BRL","SGD","PLN","INR","KRW","RON","CNY","SEK","EUR"]
    // AUD, DKK, SEK, BGN dosent Work
    var finalStringCurrency = ""

    @IBOutlet weak var currencyRateLabel: UILabel!
    @IBOutlet weak var currencyRatePicker: UIPickerView!
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyCountryRate[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyCountryRate.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        finalStringCurrency = getURL + currencyCountryRate[row]
        getCurrencyRateData(url: finalStringCurrency)
        print(currencyCountryRate[row])
        print(finalStringCurrency)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        currencyRatePicker.dataSource = self
        currencyRatePicker.delegate = self
        
    }
    
    func getCurrencyRateData(url: String) {


        Alamofire.request(url)
            .responseJSON { response in
                if response.result.isSuccess {
                    print("successfully received currency rate")
                    let currencyJSON : JSON = JSON(response.result.value!)
                    self.updateCurrencyData(json: currencyJSON)
                   
                } else {
                    print("Error: \(String(describing: response.result.error))")
                    self.currencyRateLabel.text = "Error try again"
                }
            }
        
    }
    // THE IF LET CURRENCYURLRESULT IS BEING SKIPPED
    func updateCurrencyData(json : JSON) {
        if  let currencyURLResult = json["rates"].double{
            currencyRateLabel.text = "\(currencyURLResult)"
            print("bananas")
        }else{
            currencyRateLabel.text = "Currency Unavailable"
            // print(json["rates"])
        }
    }
    
    

}

