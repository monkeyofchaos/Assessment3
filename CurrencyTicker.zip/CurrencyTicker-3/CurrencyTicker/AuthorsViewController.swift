//
//  AuthorsViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 28/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import CoreData
import Firebase
import FirebaseCore
import FirebaseDatabase


class AuthorsViewController: UIViewController {

    @IBOutlet weak var author1: UILabel!
    @IBOutlet weak var author2: UILabel!
    @IBOutlet weak var author3: UILabel!
    @IBOutlet weak var goHome: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        readFirebaseData()
    }
    
    @IBAction func homeBtn(_ sender: Any) {
       performSegue(withIdentifier: "home", sender: self)
    }
    
    func readFirebaseData(){
        let myRef = Database.database().reference()
        
        myRef.child("author1").observeSingleEvent(of: .value) { (snapShot) in
            let authorData = snapShot.value as? [String:Any]
            let author1 = snapShot.value as? String
            self.author1.text = author1
        }

        myRef.child("author2").observeSingleEvent(of: .value) { (snapShot) in
            let authorData2 = snapShot.value as? [String:Any]
            let author2 = snapShot.value as? String
            self.author2.text = author2
        }
        
        myRef.child("author3").observe(.value, with: { (snapShot) in
            let authorData3 = snapShot.value as? [String:Any]
            let author3 = snapShot.value as? String
            self.author3.text = author3
        })
        
   }
}
