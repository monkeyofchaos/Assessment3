//
//  AuthorsViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 28/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import CoreData
import Firebase
import FirebaseCore
import FirebaseDatabase

struct Authorname{
    var name:String
    var position:String
}

class AuthorsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    
    let changeStyleSwitch = "stylesSwitch"
    let saveDefault = UserDefaults.standard
    
    var authorName = [Authorname]()
     var authorRef:DatabaseReference!
    @IBOutlet weak var authorTable: UITableView!
    @IBOutlet weak var goHome: UIButton!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var positionText: UITextField!
    //    @IBOutlet weak var authorName: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        authorRef = Database.database().reference()
        authorTable.dataSource = self
        authorTable.delegate = self
    }
    override func viewDidAppear(_ animated: Bool) {
        getData()
    }
    
    
  
    
    @IBAction func homeBtn(_ sender: Any) {
       performSegue(withIdentifier: "home", sender: self)
    }
    
    func addAuthor(){
        let author = ["Name":textField.text!,"Position":positionText.text!]
        authorRef.child("Author").childByAutoId().setValue(author)
    }
    @IBAction func addAuthor(_ sender: UIButton) {
        addAuthor()
    }
    func getData(){
        authorRef?.child("Author").queryOrderedByKey().observe(.childAdded, with: { (snapshot) in
            guard let value = snapshot.value as? [String:Any] else{return}
            let name = value["Name"] as? String
            let position = value["Position"] as? String
            self.authorName.append(Authorname(name:name!,position:position!))
            self.authorTable.reloadData()
        })
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authorName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let name = cell?.viewWithTag(1) as! UILabel
        name.text = authorName[indexPath.row].name
        let position = cell?.viewWithTag(2) as! UILabel
        position.text = authorName[indexPath.row].position
        print(authorName[indexPath.row].name)
        print(authorName[indexPath.row].position)
        return cell!
    }


}
