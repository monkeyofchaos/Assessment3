//
//  ViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 21/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import FirebaseDatabase
import Firebase

class ViewController: UIViewController, UIPickerViewDataSource ,UIPickerViewDelegate {
    
    
    let getURL = "https://openexchangerates.org/api/latest.json?app_id=4b8edc48a2b24552a15c897c0f70d18c&base=USD"
    var currencyCountryRate = ["AUD","ARS","BDT","BRL","CAD","CNY","CRC","EUR","GBP","GHS","HKD","IDR","ILS","INR","JPY","KHR","KRW","KPW","LAK","LKR","MNT","MUR","MXN","NOK","NZD","PLN","PYG","QAR","RON","RUB","SCR","SEK","SGD","THB","TRY","UAH","VND","ZAR"]
    let currencySymbolRate =
        ["$","₳","৳","₢", "$", "¥","₡","€", "£","₵","$", "Rp", "₪", "₹", "¥","៛","₩","₩","₭", "₨","₮" ,"₨", "$", "kr", "$", "zł","₲","﷼" , "lei", "₽", "₨" , "kr", "$","฿", "₺","₴","₫","R"]
    
    

    var finalStringCurrency = ""
    var currentCurrencySelected = ""
    
    // Custom colors
    let colorCustomBlue = UIColor(named: "myColor1")
    let colorCustomBlue2 = UIColor(named: "myColor2")
    let colorCustomLight = UIColor(named: "myColorLight")
    let colorCustomDark = UIColor(named: "myColorDark")
    
    @IBOutlet weak var currencyRateLabel: UILabel!
    @IBOutlet weak var currencyRatePicker: UIPickerView!
    @IBOutlet weak var settingsBtn: UIButton!
    @IBOutlet weak var themeSwitch: UISwitch!
    let changeStyleSwitch = "stylesSwitch"
    let saveDefault = UserDefaults.standard
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyCountryRate[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyCountryRate.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        finalStringCurrency = getURL
        getCurrencyRateData(url: finalStringCurrency, selectedRowValue: currencyCountryRate[row] )
        currentCurrencySelected = currencySymbolRate[row]
        print(currencyCountryRate[row])
        print(finalStringCurrency)
        print(self.currencyCountryRate.count)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currencyRatePicker.dataSource = self
        currencyRatePicker.delegate = self
        
        checkLoadStyles()
        checkCurrentTheme()
    }
    
    @IBAction func goToAuthorPage(_ sender: Any) {
        performSegue(withIdentifier: "goToAuthor", sender: self)
    }
    
    
    func getCurrencyRateData(url: String, selectedRowValue: String ) {
        Alamofire.request(url)
            .responseJSON { response in
                if response.result.isSuccess {
                    print("successfully received currency rate")
                    let currencyJSON : JSON = JSON(response.result.value!)
                    self.updateCurrencyData(json: currencyJSON, selectedRowValue: selectedRowValue)
                    
                } else {
                    print("Error: \(String(describing: response.result.error))")
                    self.currencyRateLabel.text = "Error try again"
                }
        }
        
    }
    
    func updateCurrencyData(json : JSON, selectedRowValue: String ) {
        if let currencyURLResult = json["rates"][selectedRowValue].double{
            currencyRateLabel.text = "1 USD = \(currentCurrencySelected) \(currencyURLResult)"
        }else{
            currencyRateLabel.text = "Currency Unavailable"
        }
    }
    
 
    func checkLoadStyles(){
        if let fixColor = saveDefault.value(forKey: changeStyleSwitch){
            themeSwitch.isOn = fixColor as! Bool
            settingsBtn.tintColor = colorCustomLight
        }else{
            //self.view.backgroundColor = UIColor.blue
            self.view.backgroundColor = colorCustomBlue
            settingsBtn.tintColor = colorCustomDark
        }
    }
    
    func checkCurrentTheme(){
        if themeSwitch.isOn == true{
            self.view.backgroundColor = colorCustomBlue2
            settingsBtn.tintColor = colorCustomLight
        }else{
            self.view.backgroundColor = colorCustomBlue
            settingsBtn.tintColor = colorCustomDark
        }
    }
    
    
    @IBAction func themeStyleSwitch(_ sender: Any) {
        if themeSwitch.isOn {
            themeSwitch.setOn(false, animated:true)
            //self.view.backgroundColor = UIColor.blue dont hardcode color make custom color like under
            self.view.backgroundColor = colorCustomBlue
            currencyRateLabel?.font = currencyRateLabel?.font.withSize(30)
            currencyRateLabel?.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.thin)
            settingsBtn.tintColor = colorCustomDark
        } else {
            themeSwitch.setOn(true, animated:true)
            self.view.backgroundColor = colorCustomBlue2
            currencyRateLabel?.font = currencyRateLabel?.font.withSize(26)
            currencyRateLabel?.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.regular)
            settingsBtn.tintColor = colorCustomLight
        }
   
        saveDefault.set((sender as AnyObject).isOn, forKey:changeStyleSwitch)
    }
    

}

