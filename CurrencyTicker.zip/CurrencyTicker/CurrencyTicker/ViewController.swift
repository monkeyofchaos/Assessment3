//
//  ViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 21/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import FirebaseDatabase
import Firebase

class ViewController: UIViewController, UIPickerViewDataSource ,UIPickerViewDelegate {
    
    
    @IBOutlet weak var settingsBtn: UIButton!
    
    
    let getURL = "https://openexchangerates.org/api/latest.json?app_id=4b8edc48a2b24552a15c897c0f70d18c&base=USD"
    let currencyCountryRate = ["AUD","ARS","BDT","BRL","CAD","CNY","CRC","EUR","GBP","GHS","HKD","IDR","ILS","INR","JPY","KHR","KRW","KPW","LAK","LKR","MNT","MUR","MXN","NOK","NZD","PLN","PYG","QAR","RON","RUB","SCR","SEK","SGD","THB","TRY","UAH","VND","ZAR"]
    let currencySymbolRate =
        ["$","₳","৳","₢", "$", "¥","₡","€", "£","₵","$", "Rp", "₪", "₹", "¥","៛","₩","₩","₭", "₨","₮" ,"₨", "$", "kr", "$", "zł","₲","﷼" , "lei", "₽", "₨" , "kr", "$","฿", "₺","₴","₫","R"]
    
    

    var finalStringCurrency = ""
    var currentCurrencySelected = ""
    
    @IBOutlet weak var currencyRateLabel: UILabel!
    @IBOutlet weak var currencyRatePicker: UIPickerView!
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyCountryRate[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyCountryRate.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        finalStringCurrency = getURL
        getCurrencyRateData(url: finalStringCurrency, selectedRowValue: currencyCountryRate[row] )
        currentCurrencySelected = currencySymbolRate[row]
        print(currencyCountryRate[row])
        print(finalStringCurrency)
        print(self.currencyCountryRate.count)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currencyRatePicker.dataSource = self
        currencyRatePicker.delegate = self
        

//        let settingsView = SettingsViewController()
//        settingsView.checkLoadColor()
//
//        if settingsView.colorSwitch.isOn == true{
//            self.view.backgroundColor = UIColor.blue
//            view.backgroundColor = UIColor.blue
//        }
    }
    
    func getCurrencyRateData(url: String, selectedRowValue: String ) {
        Alamofire.request(url)
            .responseJSON { response in
                if response.result.isSuccess {
                    print("successfully received currency rate")
                    let currencyJSON : JSON = JSON(response.result.value!)
                    self.updateCurrencyData(json: currencyJSON, selectedRowValue: selectedRowValue)
                    
                } else {
                    print("Error: \(String(describing: response.result.error))")
                    self.currencyRateLabel.text = "Error try again"
                }
        }
        
    }
    
    func updateCurrencyData(json : JSON, selectedRowValue: String ) {
        if let currencyURLResult = json["rates"][selectedRowValue].double{
            currencyRateLabel.text = "1 USD = \(currentCurrencySelected) \(currencyURLResult)"
        }else{
            currencyRateLabel.text = "Currency Unavailable"
        }
    }
    
    
    @IBAction func settinsButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "goToSettingsView", sender: self)
    }
    
}

