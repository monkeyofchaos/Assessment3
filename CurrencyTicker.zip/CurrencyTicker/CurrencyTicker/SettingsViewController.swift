//
//  SettingsViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 25/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class SettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
//    let refDB = Database.database().reference()
//    refDB.child("someid/name").setValue("name":"")
    

    
    
    
    
    @IBAction func goBack(_ sender: Any) {
         performSegue(withIdentifier: "goBack", sender: self)
    }
    
}
