//
//  SettingsViewController.swift
//  CurrencyTicker
//
//  Created by Ryan Zad on 25/5/19.
//  Copyright © 2019 Ryan Zad. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import FirebaseDatabase
import Firebase

class SettingsViewController: UIViewController {
    
    
    @IBOutlet weak var colorSwitch: UISwitch!
    @IBOutlet weak var colorSwitch2: UISwitch!
    @IBOutlet weak var colorSwitch3: UISwitch!
    
    @IBOutlet weak var settingsHeading: UILabel!
    @IBOutlet weak var colorHeading: UILabel!
    @IBOutlet weak var fontSizeHeading: UILabel!
    @IBOutlet weak var fontStyleHeading: UILabel!
    
    let changeColSwitch = "colorSwitch"
    let saveDefault = UserDefaults.standard
    let viewControlCurrency = ViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkLoadColor()

        if colorSwitch.isOn == true{
            self.view.backgroundColor = UIColor.blue
            //viewControlCurrency.view.backgroundColor = UIColor.blue
        }else{
            self.view.backgroundColor = UIColor.gray
        }
    }
    
    @IBAction func authorButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "goToAuthors", sender: self)
    }
    
    
    func checkLoadColor(){
        if let fixColor = saveDefault.value(forKey: changeColSwitch){
            colorSwitch.isOn = fixColor as! Bool
            //self.view.backgroundColor = UIColor.blue
        }else{
            self.view.backgroundColor = UIColor.gray
        }
    }

    @IBAction func changeColorsSwitch(_ sender: Any) {
        if colorSwitch.isOn {
            colorSwitch.setOn(false, animated:true)
            self.view.backgroundColor = UIColor.gray
        } else {
            colorSwitch.setOn(true, animated:true)
            self.view.backgroundColor = UIColor.blue
        }
        saveDefault.set((sender as AnyObject).isOn, forKey:changeColSwitch)
    }
    
    
    @IBAction func changeFontSize(_ sender: Any) {

        if colorSwitch2.isOn {
            colorSwitch2.setOn(false, animated:true)
            settingsHeading?.font = settingsHeading?.font.withSize(24)
            colorHeading?.font = colorHeading?.font.withSize(24)
            fontSizeHeading?.font = fontSizeHeading?.font.withSize(24)
            fontStyleHeading?.font = fontStyleHeading?.font.withSize(24)
        } else {
            colorSwitch2.setOn(true, animated:true)
            settingsHeading?.font = settingsHeading?.font.withSize(26)
            colorHeading?.font = colorHeading?.font.withSize(26)
            fontSizeHeading?.font = fontSizeHeading?.font.withSize(26)
            fontStyleHeading?.font = fontStyleHeading?.font.withSize(26)
        }
        
    }
    
    @IBAction func changeFontStyle(_ sender: Any) {
        if colorSwitch3.isOn {
            colorSwitch3.setOn(false, animated:true)
            settingsHeading?.font = settingsHeading?.font.withSize(24)
            colorHeading?.font = colorHeading?.font.withSize(24)
            fontSizeHeading?.font = fontSizeHeading?.font.withSize(24)
            fontStyleHeading?.font = fontStyleHeading?.font.withSize(24)
        } else {
            colorSwitch3.setOn(true, animated:true)
            settingsHeading?.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.thin)
            colorHeading?.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.thin)
            fontSizeHeading?.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.thin)
            fontStyleHeading?.font = UIFont.systemFont(ofSize: 26.0, weight: UIFont.Weight.thin)
        }
    }
    
    
    
    @IBAction func goBack(_ sender: Any) {
         performSegue(withIdentifier: "goBack", sender: self)
    }
    
}
